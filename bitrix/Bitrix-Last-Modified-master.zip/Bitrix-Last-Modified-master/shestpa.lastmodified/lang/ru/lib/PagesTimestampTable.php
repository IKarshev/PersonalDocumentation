<?php
defined('B_PROLOG_INCLUDED') and (B_PROLOG_INCLUDED === true) or die();

$MESS['ID'] = 'ID';
$MESS['URL'] = 'URL страницы';
$MESS['HASH'] = 'Хеш контента страницы';
$MESS['LAST_MODIFIED'] = 'Дата изменения страницы';
